console.log("Name : Sanket Rajnor")
console.log("Class : TE - IT")
console.log("Roll No : 58")
console.log("Subject : WAD")